package com.example.EmployeeCrud.service;

import com.example.EmployeeCrud.dto.EmployeeDto;
import com.example.EmployeeCrud.model.EmployeeModel;

public interface UtilityConvertService {
    EmployeeDto convertToDto(EmployeeModel employeeModel);
    EmployeeModel convertToModel(EmployeeDto employeeDto);


}
