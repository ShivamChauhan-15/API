package com.example.EmployeeCrud.service;

import com.example.EmployeeCrud.dto.EmployeeDto;
import com.example.EmployeeCrud.model.EmployeeModel;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

@Service
public class UtilityConvertServiceImpl implements UtilityConvertService {

    @Override
    public EmployeeDto convertToDto(EmployeeModel employeeModel){
       if(employeeModel!=null){
           Long empId=employeeModel.getEmpId();
           String firstName= employeeModel.getFirstName();
           String lastName= employeeModel.getLastName();
           String address= employeeModel.getAddress();
           String city= employeeModel.getCity();
           String pincode= employeeModel.getPincode();
           if(StringUtils.isAnyBlank(firstName,lastName,address,city,pincode))
               throw new IllegalArgumentException("Field is empty");

           //creating new EmployeeDto object
           EmployeeDto employeeDto=new EmployeeDto();
           employeeDto.setEmpId(empId);
           employeeDto.setFirstName(firstName);
           employeeDto.setLastName(lastName);
           employeeDto.setAddress(address);
           employeeDto.setCity(city);
           employeeDto.setPincode(pincode);
           return employeeDto;

       }
       throw new RuntimeException("Object is null");
    }

    @Override
    public EmployeeModel convertToModel(EmployeeDto employeeDto){
        if(employeeDto!=null){
            String firstName= employeeDto.getFirstName();
            String lastName= employeeDto.getLastName();
            String address= employeeDto.getAddress();
            String city= employeeDto.getCity();
            String pincode= employeeDto.getPincode();
            if(StringUtils.isAnyBlank(firstName,lastName,address,city,pincode))
                throw new IllegalArgumentException("Field is empty");

            //creating new EmployeeModel Object
            EmployeeModel employeeModel=new EmployeeModel();
            employeeModel.setFirstName(firstName);
            employeeModel.setLastName(lastName);
            employeeModel.setAddress(address);
            employeeModel.setCity(city);
            employeeModel.setPincode(pincode);
            return employeeModel;
        }
        throw new RuntimeException("Object is null");
    }


}
