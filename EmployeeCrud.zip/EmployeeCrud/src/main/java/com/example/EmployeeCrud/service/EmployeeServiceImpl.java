package com.example.EmployeeCrud.service;

import com.example.EmployeeCrud.dto.EmployeeDto;
import com.example.EmployeeCrud.model.EmployeeModel;
import com.example.EmployeeCrud.repository.EmployeeRepository;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService{
    @Autowired
    private EmployeeRepository employeeRepository;
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private UtilityConvertService utilityService;

    //create employee
    @Override
    public EmployeeDto saveEmployee(EmployeeDto empDto) {
        try{
            return utilityService.convertToDto(employeeRepository.save(utilityService.convertToModel(empDto)));
        }
        catch (Exception e){
            System.out.println(e);
            return null;
        }

    }

    //to fetch list of all employees
    @Override
    public List<EmployeeDto> fetchAllEmployees() {
        List<EmployeeModel> allEmployees = employeeRepository.findAll();
        List<EmployeeDto> allEmpDto=new ArrayList<>();
        try{
            return allEmployees.stream()
                    .map(employeeModel -> utilityService.convertToDto(employeeModel))
                    .collect(Collectors.toList());
        }
        catch (Exception e){
            System.out.println(e);
            return null;
        }

    }

    //to fetch particular employee
    @Override
    public EmployeeDto getEmployeeById(Long id) {
        try{
            return employeeRepository.findById(id)
                    .map(employeeModel -> utilityService.convertToDto(employeeModel))
                    .orElse(null);
        }
        catch (Exception e){
            System.out.println(e);
            return null;
        }

    }

    //to update partial details of employee by id using patch
    public EmployeeDto updateEmployeePartially(Long id, Map<String,Object> resourcesToUpdate) {
        return employeeRepository.findById(id)
                .map(employeeModel -> {
                    for (Map.Entry<String, Object> entry : resourcesToUpdate.entrySet()) {
                        String key = entry.getKey();
                        Object value = entry.getValue();
                        if(StringUtils.isBlank(value.toString()))
                            return null;
                        switch (key) {
                            case "firstName":
                                employeeModel.setFirstName(value.toString());
                                break;
                            case "lastName":
                                employeeModel.setLastName(value.toString());
                                break;
                            case "address":
                                employeeModel.setAddress(value.toString());
                                break;
                            case "city":
                                employeeModel.setCity(value.toString());
                                break;
                            case "pincode":
                                employeeModel.setPincode(value.toString());
                                break;
                            default:
                                return null;
                        }
                    }
                    // Save the updated employeeModel
                    employeeModel = employeeRepository.save(employeeModel);
                    try{
                        return utilityService.convertToDto(employeeModel);
                    }
                    catch (RuntimeException re){
                        System.out.println(re);
                        return null;
                    }

                })
                .orElse(null);
    }

    //to update employee details by providing entire resource using put
    @Override
    public EmployeeDto updateEmployeeById(Long empId, EmployeeDto empDto) {
        try{
            return employeeRepository.findById(empId)
                    .map(employeeModel -> {
                        if(StringUtils.isAnyBlank(empDto.getFirstName(),empDto.getLastName(),empDto.getAddress(),empDto.getCity(),empDto.getPincode()))
                            return null;
                        employeeModel.setFirstName(empDto.getFirstName());
                        employeeModel.setLastName(empDto.getLastName());
                        employeeModel.setAddress(empDto.getAddress());
                        employeeModel.setCity(empDto.getCity());
                        employeeModel.setPincode(empDto.getPincode());
                        return utilityService.convertToDto(employeeRepository.save(employeeModel));
                    })
                    .orElseGet(() -> {
                        EmployeeModel employeeModel = utilityService.convertToModel(empDto);
                        return utilityService.convertToDto(employeeRepository.save(employeeModel));
                    });
        }
        catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

    //to delete particular employee by id
    @Override
    public boolean deleteEmployeeById(Long empId) {
        if (employeeRepository.findById(empId).isPresent()) {
            employeeRepository.deleteById(empId);
            return true;
        }
        return false;
    }


    //to check if employee exists or not
    public boolean checkIfExist(Long empId){
        return employeeRepository.existsById(empId);
    }
}
