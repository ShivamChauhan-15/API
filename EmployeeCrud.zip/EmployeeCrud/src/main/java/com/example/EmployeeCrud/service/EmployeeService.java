package com.example.EmployeeCrud.service;

import com.example.EmployeeCrud.dto.EmployeeDto;

import java.util.List;
import java.util.Map;

public interface EmployeeService {
    EmployeeDto saveEmployee(EmployeeDto empDto);

    List<EmployeeDto> fetchAllEmployees();

    EmployeeDto getEmployeeById(Long id);

    EmployeeDto updateEmployeePartially(Long id, Map<String,Object> resourceToUpdate);

    EmployeeDto updateEmployeeById(Long id,EmployeeDto empDto);

    boolean deleteEmployeeById(Long id);
    boolean checkIfExist(Long empId);
}
